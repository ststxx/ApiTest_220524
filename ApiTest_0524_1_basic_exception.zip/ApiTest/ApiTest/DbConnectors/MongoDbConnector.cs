﻿using ApiTest.Models.Entities;
using MongoDB.Driver;

namespace ApiTest.DbConnectors
{
    public class MongoDbConnector
    {
        public IMongoCollection<User> UsersCollection;
        public MongoDbConnector()
        {
            var connectionString = "mongodb://localhost:27017";
            var client = new MongoClient(connectionString);
            var db = client.GetDatabase("apitest");
            UsersCollection = db.GetCollection<User>("users");
        }
    }
}
