﻿using ApiTest.Exceptions;
using ApiTest.Models.Dtos;
using ApiTest.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace ApiTest.Controllers
{
    [Route("users")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly MongoUserRepository _users;
        public UserController(MongoUserRepository mongoUserRepository)
        {
            _users = mongoUserRepository;
        }

        [HttpGet]
        public async Task<IActionResult> FindAll()
        {
            try
            {
                return Ok(_users.FindAll());
            }
            catch (Exception e)
            {
                throw;
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> FindById(string id)
        {
            try
            {
                return Ok(_users.FindById(id));
            }
            catch (Exception e)
            {
                return ExceptionHandler(e);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Create(UserCreateDto userCreateDto)
        {
            try
            {
                return Ok(_users.Create(userCreateDto));
            }
            catch (Exception e)
            {
                throw;
            }
        }

        private IActionResult ExceptionHandler(Exception e)
        {
            HttpContext.Response.ContentType = "application/json";
            if (e is UnknownException)
                return BadRequest((e as UnknownException).ToErrorResponse());
            if (e is IdNotExistException)
                return BadRequest((e as IdNotExistException).ToErrorResponse());
            if (e is IdLengthException)
                return BadRequest((e as IdLengthException).ToErrorResponse());
            return BadRequest(e.ToString());
        }
    }
}
