﻿namespace ApiTest.Attributes.Enums
{
    public enum AttributeTypes
    {
        LOGIN
    }
}
