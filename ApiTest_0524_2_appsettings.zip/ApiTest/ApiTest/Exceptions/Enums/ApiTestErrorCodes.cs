﻿namespace ApiTest.Exceptions.Enums
{
    public enum ApiTestErrorCodes
    {
        UNKNOWN,
        IDNOTEXIST,
        IDLENGTH,
    }
}
